//
//  BeliTableViewCell.swift
//  Telkomsel-UI-NEW
//
//  Created by Muhammad Syabran on 09/03/23.
//

import UIKit

class BeliTableViewCell: UITableViewCell {
    
    static let identifier = "BeliTableViewCell"

    @IBOutlet weak var beliView: UIView!
    @IBOutlet weak var beliButton: UIButton!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    @IBAction func beliSekarangAction(_ sender: Any) {
        
    }
    
}
