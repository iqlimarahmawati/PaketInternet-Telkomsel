//
//  MasaAktifTableViewCell.swift
//  Telkomsel-UI-NEW
//
//  Created by Phincon on 08/03/23.
//

import UIKit

class MasaAktifTableViewCell: UITableViewCell {

    static let identifier = "MasaAktifTableViewCell"
    
    @IBOutlet weak var masaAktif: UILabel!
    @IBOutlet weak var durasiMasaAktif: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
       
    }

    
    }
    

