//
//  PaketTotalTableViewCell.swift
//  Telkomsel-UI-NEW
//
//  Created by Muhammad Syabran on 08/03/23.
//

import UIKit

class PaketTotalTableViewCell: UITableViewCell {
    
    static let identifier = "PaketTotalTableViewCell"

    @IBOutlet weak var namaPaketLabel: UILabel!
    @IBOutlet weak var totalKuotaLabel: UILabel!
    @IBOutlet weak var hargaAsliLabel: UILabel!
    @IBOutlet weak var hargaDiskonLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
