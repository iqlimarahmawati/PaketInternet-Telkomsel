//
//  RincianPaketTableViewCell.swift
//  Telkomsel-UI-NEW
//
//  Created by Phincon on 08/03/23.
//

import UIKit

class RincianPaketTableViewCell: UITableViewCell {

    static let identifier = "RincianPaketTableViewCell"
    
    @IBOutlet weak var internetLabel: UILabel!
    
    @IBOutlet weak var omgLabel: UILabel!
    
    @IBOutlet weak var smsLabel: UILabel!
    
    @IBOutlet weak var voiceLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
      
    }

   
    }
    

