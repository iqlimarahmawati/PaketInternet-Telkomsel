//
//  DetailViewController.swift
//  Telkomsel-UI-NEW
//
//  Created by Phincon on 08/03/23.
//

import UIKit

//enum DetailSection {
//    case paketTotal
//    case masaAktifPaket
//    case rincianPaket
//    case DeskripsiPaket
//    case beliSekarang
//}

class DetailViewController: UIViewController {
    
//    var section: DetailSection?
    
    var paket: PaketModel?

    @IBOutlet weak var DetailPaketTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupDetailTableview()
    }

    func setupDetailTableview(){
        DetailPaketTableView.delegate = self
        DetailPaketTableView.dataSource = self
        DetailPaketTableView.separatorStyle = .none
        
        DetailPaketTableView.register(UINib(nibName: "PaketTotalTableViewCell", bundle: nil), forCellReuseIdentifier: PaketTotalTableViewCell.identifier)
        
        DetailPaketTableView.register(UINib(nibName: "MasaAktifTableViewCell", bundle: nil), forCellReuseIdentifier: MasaAktifTableViewCell.identifier)
        
        DetailPaketTableView.register(UINib(nibName: "RincianPaketTableViewCell", bundle: nil), forCellReuseIdentifier: RincianPaketTableViewCell.identifier)
        
        DetailPaketTableView.register(UINib(nibName: "DeskripsiPaketTableViewCell", bundle: nil), forCellReuseIdentifier: DeskripsiPaketTableViewCell.identifier)
        
        DetailPaketTableView.register(UINib(nibName: "BeliTableViewCell", bundle: nil), forCellReuseIdentifier: BeliTableViewCell.identifier)
    }
}

extension DetailViewController: UITableViewDataSource, UITableViewDelegate {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 5
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        switch indexPath.section {
        case 0:
            guard let cell = DetailPaketTableView.dequeueReusableCell(withIdentifier: PaketTotalTableViewCell.identifier, for: indexPath) as? PaketTotalTableViewCell else {
                return UITableViewCell()
            }
            cell.namaPaketLabel.text = self.paket?.jenisPaket
            cell.totalKuotaLabel.text = self.paket?.paket
            cell.hargaAsliLabel.text = self.paket?.hargaAsli
            cell.hargaDiskonLabel.text = self.paket?.hargaDiskon
            
            return cell
            
        case 1:
            guard let cell = DetailPaketTableView.dequeueReusableCell(withIdentifier: MasaAktifTableViewCell.identifier, for: indexPath) as? MasaAktifTableViewCell else {
                return UITableViewCell()
            }
            cell.durasiMasaAktif.text = self.paket?.durasi
            return cell
            
        case 2:
            guard let cell = DetailPaketTableView.dequeueReusableCell(withIdentifier: RincianPaketTableViewCell.identifier, for: indexPath) as? RincianPaketTableViewCell else {
                return UITableViewCell()
            }
            cell.internetLabel.text = self.paket?.internet
            cell.omgLabel.text = self.paket?.omg
            cell.smsLabel.text = self.paket?.sms
            cell.voiceLabel.text = self.paket?.voice
            
            return cell
            
        case 3:
            guard let cell = DetailPaketTableView.dequeueReusableCell(withIdentifier: DeskripsiPaketTableViewCell.identifier, for: indexPath) as? DeskripsiPaketTableViewCell else {
                return UITableViewCell()
            }
            cell.deskripsiLabel.text = self.paket?.deskripsi
            
            return cell
            
        case 4:
            guard let cell = DetailPaketTableView.dequeueReusableCell(withIdentifier: BeliTableViewCell.identifier, for: indexPath) as? BeliTableViewCell else {
                return UITableViewCell()
            }
            return cell
            
        default:
            return UITableViewCell()
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        switch indexPath.section {
        case 0:
            return 145
        case 1:
            return 44
        case 2:
            return 176
        case 3:
            return 300
        case 4:
            return 44
        default:
            return 0
        }
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        switch indexPath.section {
        case 4:
            print("Beli Sekarang")
            let beliVC = BerhasilViewController()
            beliVC.paket = self.paket
            
            self.navigationController?.pushViewController(beliVC, animated:true)
            
        default:
            return
        }
    }
}
