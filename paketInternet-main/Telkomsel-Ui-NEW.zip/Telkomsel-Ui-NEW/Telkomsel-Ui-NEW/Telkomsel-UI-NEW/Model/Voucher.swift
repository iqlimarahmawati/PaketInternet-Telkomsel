//
//  Voucher.swift
//  Telkomsel-Ui-NEW
//
//  Created by Phincon on 08/03/23.
//

import Foundation

struct VoucherModel {
    var imageVoucher: String
    var judul: String
}
