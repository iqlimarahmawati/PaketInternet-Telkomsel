//
//  ImagePaket.swift
//  Telkomsel-Ui-NEW
//
//  Created by Phincon on 07/03/23.
//

import Foundation
struct imageDataModel {
    var imageDataModel: String
}
