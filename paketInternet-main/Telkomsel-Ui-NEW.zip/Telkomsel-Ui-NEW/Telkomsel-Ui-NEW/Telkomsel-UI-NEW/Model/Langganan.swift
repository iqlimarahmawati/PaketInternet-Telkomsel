//
//  Langganan.swift
//  Telkomsel-Ui-NEW
//
//  Created by Phincon on 07/03/23.
//

import Foundation

struct PaketModel {
    var paket: String
    var durasi: String
    var hargaAsli: String
    var hargaDiskon: String
    var jenisPaket: String
    var internet: String
    var omg: String
    var sms: String
    var voice: String
    var deskripsi: String
}
