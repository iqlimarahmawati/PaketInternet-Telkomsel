//
//  ImagePaketCollectionViewCell.swift
//  Telkomsel-Ui-NEW
//
//  Created by Phincon on 07/03/23.
//

import UIKit

class ImagePaketCollectionViewCell: UICollectionViewCell {
    
    static let identifier = "ImagePaketCollectionViewCell"
    
    @IBOutlet weak var imagePaket: UIImageView!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
       
    }

}



